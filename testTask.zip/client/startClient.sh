#!/bin/bash
java -cp .:client-1.0.jar ru.neron.education.simpleserver.client.Client
