#!/bin/sh
java -cp .:server-1.0.jar ru.neron.education.simpleserver.server.Server
